# dsh-whale-persona

把「鲸鱼娘」人设塞进系统提示词的极简 DSH（DeepSeek Harness）插件。

## 它做什么

- 只调一次 `ctx.systemPrompt.section({ name: 'whale-persona', order: 900, text: PERSONA })`。
- 不注册工具、路由、配置项、监听器 —— 除人设正文外**没有任何额外内容**。
- 人设位于系统提示词的稳定前缀中：每轮对话自动生效，命中 prompt cache 后每轮约按 1/10 计费。

## 改风格

编辑 `index.js` 里的 `PERSONA` 常量，保存后重载 DSH（HMR 开着的 profile 会自动重载插件）。

## 安装（手动挂载到某个 profile）

```powershell
# 1) 放进 profile 的 node_modules（hoisted 布局，直接目录/junction 即可）
$p = "$env:USERPROFILE\.dsh\profiles\desktop\node_modules\dsh-whale-persona"
New-Item -ItemType Junction -Path $p -Target "E:\ds1\plugins\dsh-whale-persona"

# 2) 在 profile 的 patch 层插入插件行
Add-Content "$env:USERPROFILE\.dsh\profiles\desktop\cordis.patch.yml" @"
- insert:
    - id: whale-persona
      name: 'dsh-whale-persona'
"@
```

配置树重载后即生效（DSH 会监听 profile 配置变化）。

## 卸载

删掉 profile 的 `cordis.patch.yml` 里的那条 insert，并删除 `node_modules\dsh-whale-persona`。

## 发布与他人安装

只把仓库传上 GitHub，别人**不能一键装**。DSH 生态的安装通道有三条，按优先级：

1. **npm 包（首选，最快）** —— `npm publish` 之后，别人可以在插件市场里装，或手动：

   ```powershell
   cd "$env:USERPROFILE\.dsh\profiles\desktop"
   pnpm add dsh-whale-persona
   ```

   再把 `dsh-whale-persona` 加进该 `package.json` 的 `dsh.profile.bundles`。bundle 自带的 `cordis.patch.yml` 会自动插入插件行，**不用手改配置**。

2. **GitHub Release 预构建 tarball** —— `pnpm pack` 出 `dsh-whale-persona-0.1.0.tgz`，贴到 Release；市场支持按链接安装这类压缩包，几秒装完、不执行构建脚本。

3. **整仓源码下载（兜底）** —— 仓库本身是合法包时，市场会回退到 GitHub 归档下载；不需要 `git`，但要能访问 GitHub，且每次安装都拉整仓。

要让 1、2 顺利，包内必须有：`package.json`（`type` / `main` / `exports` / `files` 齐全）、`cordis.patch.yml`、以及 `dsh.bundle.patch` 声明 —— 本仓库已齐。

### 上架到插件市场

市场目录来自 [awesome-dsh-plugin](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin)，去那边提一条 PR 即可（站点与市场会自动收录，通常一天内生效）。建议同时补：一句话简介、截图、`engines.dsh` 或 `@deepseek-ai/dsh-*` peer 声明（不写也能显示，只是不参与兼容性筛选）。
